namespace FluentAssertions.Equivalency;

/// <summary>
/// Allows deferred fetching of the subject ID.
/// </summary>
public delegate string GetSubjectId();
