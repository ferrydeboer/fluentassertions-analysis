namespace FluentAssertions.Equivalency;

public enum EquivalencyResult
{
    ContinueWithNext,
    AssertionCompleted
}
