﻿namespace FluentAssertions.Common;

/// <summary>
/// Factory for starting a timer on demand.
/// </summary>
public delegate ITimer StartTimer();
