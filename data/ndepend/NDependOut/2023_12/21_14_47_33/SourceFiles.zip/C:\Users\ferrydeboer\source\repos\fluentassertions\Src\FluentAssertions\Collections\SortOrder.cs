namespace FluentAssertions.Collections;

internal enum SortOrder
{
    Ascending,
    Descending
}
