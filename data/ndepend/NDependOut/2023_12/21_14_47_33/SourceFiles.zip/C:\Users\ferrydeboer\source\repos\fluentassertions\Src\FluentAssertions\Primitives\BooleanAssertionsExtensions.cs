﻿using FluentAssertions.Execution;

namespace FluentAssertions.Primitives;

public static class BooleanAssertionsExtensions
{
    public static AndConstraint<TAssertions> BeFalse<TAssertions>(this BooleanAssertions<TAssertions> context, string because = "", params object[] becauseArgs)
        where TAssertions : BooleanAssertions<TAssertions>
    {
        Execute.Assertion
            .ForCondition(context.Subject == false)
            .BecauseOf(because, becauseArgs)
            .FailWith("Expected {context:boolean} to be {0}{reason}, but found {1}.", false, context.Subject);

        return new AndConstraint<TAssertions>((TAssertions)context);
    }
}
