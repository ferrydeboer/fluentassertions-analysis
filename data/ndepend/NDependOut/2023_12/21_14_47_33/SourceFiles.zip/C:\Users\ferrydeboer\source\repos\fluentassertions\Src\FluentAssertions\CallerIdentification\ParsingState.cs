﻿namespace FluentAssertions.CallerIdentification;

internal enum ParsingState
{
    InProgress,
    GoToNextSymbol,
    Done
}
